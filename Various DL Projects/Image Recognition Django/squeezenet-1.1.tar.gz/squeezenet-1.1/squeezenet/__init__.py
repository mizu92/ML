__version__ = '1.1'
VERSION = __version__